import rastermap.rastermap

name = "rastermap"
